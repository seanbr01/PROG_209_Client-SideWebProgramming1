var planetNames = ["Jupiter", "Venus", "Saturn", "Mars", "Mercury"];
var distancesFromEarth = [5.2, 0.72, 9.5, 1.5, 1.0];
var sunnyInAugust = [false, true, false, true, true];
var output = "";

//Display the planet information
for (let i = 0; i < planetNames.length; i++)
{
    var planet = planetNames[i] + "<br>";    
    planet = planet.bold();
    planet = planet.fontcolor("green");
    output += planet;
    output += distancesFromEarth[i] + "<br>";
    output += sunnyInAugust[i] + "<br>";
    output += "----------<br>";
}

output += "<br>";
    
//Find the sunny planets

output += "These planets are sunny in August:<br>";

for (let i = 0; i < planetNames.length; i++)
{
    if(sunnyInAugust[i])
    {
        var planet = planetNames[i] + "<br>";
        planet = planet.bold();
        planet = planet.fontcolor("green");
        output += planet;
    }
}

document.getElementById('output').innerHTML = output;