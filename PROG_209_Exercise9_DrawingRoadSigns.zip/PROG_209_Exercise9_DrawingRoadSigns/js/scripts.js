function drawDoNotEnter() {
    var context = document.getElementById("doNotEnter").getContext('2d');
            
    context.strokeStyle = "red";
    context.fillStyle = "red";

    // draw circle
    context.beginPath();
    context.arc(100,100,100,0,2 * Math.PI,false);
    context.fill();
    context.lineJoin = "round";
    context.stroke();

    // draw white line
    context.strokeStyle = "white";
    context.fillStyle = "white";
    context.lineWidth = 20;
    context.moveTo(25, 100);
    context.lineTo(175, 100);
    context.lineJoin = "round";
    context.stroke();

    // draw DO NOT ENTER text
    context.fillStyle  = "white";
    context.font = "bold 30px Arial";
    context.fillText( "DO NOT" ,40, 70);
    context.fillText( "ENTER" , 50, 155);
}

function drawUnicorn () {
    var canvas = document.querySelector("#unicorn");
    var context = canvas.getContext("2d");

    context.strokeStyle = "red";
    context.lineWidth = 20;
    
    // draw circle
    context.beginPath();
    context.arc(210,230,200,0,2 * Math.PI,false);
    
    // draw line creating a crossing out sign
    context.moveTo(50, 100);
    context.lineTo(375, 350);
    context.lineJoin = "round";
    context.stroke();
    
    // Creates NO UNICORNS! text
    context.fillStyle  = "red";
    context.font = "bold 45px Arial";
    context.fillText( "NO UNICORNS!", 55, 485);
}


