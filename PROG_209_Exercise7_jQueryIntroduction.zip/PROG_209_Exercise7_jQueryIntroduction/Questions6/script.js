$(function() {
    "use strict";
    
    $('#myForm')
    	.find('a')
    	.on('click', function(e){
    		e.preventDefault();
    		
        // finds the ball object
    		var $link = $(this),
    			$img = $link.find('img'); 
    			
        // makes a copy of the ball
    		var $ghost = $img.clone() 
    						 .appendTo($link)
    						 .addClass('ghost');
    		
        // sets destination coordinates
    		var imgCoords = $img.offset(),
    			$target = $('#target'),
    			targetCoords = $target.find('p:first').offset();
    		
        // drops the ball
    		$ghost.animate({
    			'left' : targetCoords.left - imgCoords.left,
    			'top' : targetCoords.top - imgCoords.top,
    			'opacity' : .50,
    			'width' : '30px'
    		}, 1500, 'easeOutBounce', function() {
    			$(this).remove();
    		});
    });
});