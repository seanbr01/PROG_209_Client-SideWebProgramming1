Github for Web Designers
========================

Hi! Welcome to the companion reference to my lynda.com Github for Web Designers course. This reference also serves as the exercise files for my course, so you can download the exercise files from this repo as well.

##[View the companion reference site](https://seanbr01.github.io/PROG_209_04-03_Exercise/)
