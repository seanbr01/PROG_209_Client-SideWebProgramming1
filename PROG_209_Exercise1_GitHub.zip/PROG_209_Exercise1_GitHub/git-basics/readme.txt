Git Basics

I'm learning the basics of Git and Github, so this repo is really just for experimenting.